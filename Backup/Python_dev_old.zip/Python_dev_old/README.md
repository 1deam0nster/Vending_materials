# Python_dev
Coffe vending machine

Running on http://127.0.0.1:5000

run script:
python main.py


# AQSI 
run script:
python aqsi.py --amount (transaction ammount)

example:
python aqsi.py --amount 150


