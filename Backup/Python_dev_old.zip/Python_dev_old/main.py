from flask import Flask, url_for, render_template, request, json
import time, os
from serial_commands.commands import connect, open_serial, close, send, read_command, recv

app = Flask(__name__)


sugar_x = False
cream_x = False
sugar_y = False
cream_y = False
    

# Роутинг страниц
@app.route('/')
def index():
    return render_template('index.html')


@app.route('/coffe_y/', methods=['POST', 'GET'])
def coffe_y():
    if request.method == 'POST':
        #print(request.form.getlist('mycheckbox'))
        postlist = request.form.getlist('mycheckbox')
        print(postlist)


        if '2' in postlist and len(postlist) == 1:
            print("Сахар")
        if '1' in postlist and len(postlist) == 1:
            print("Сливки")
        if len(postlist) == 2:
            print("Сливки и сахар")
        if len(postlist) == 0:
            print("Кофе")
            print("connect")
            connect()
            print("connect ok")
            open_serial()
            send(b'x1\n')
            close()           
            print("send ok")
            
            program = "python aqsi.py"
            process = subprocess.Popen(["python", "aqsi.py --amount=12"])

            output = os.system('python aqsi.py --amount=24')
            if output == str(0):
                print("Транзакция не прошла")
            if output == 1:
                print("Транзакция прошла")

        return render_template('pay_y.html')

    return render_template('coffe_y.html')


@app.route('/coffe_x/')
def coffe_x():
    return render_template('coffe_x.html')


@app.route('/send_coffe_y', methods=['POST'])
def send_coffe_y():
    user =  request.form['username']
    password = request.form['password']
    print(password)
    print(user)
    return json.dumps({'status':'OK','user':user,'pass':password})


app.secret_key = 'ItShouldBeAnythingButSecret'     #you can set any secret key but remember it should be secret

#step – 3 (creating a dictionary to store information about users)
user = {"username": "abc", "password": "xyz"}

@app.route('/login', methods = ['POST', 'GET'])
def login():
    if(request.method == 'POST'):
        username = request.form.get('username')
        password = request.form.get('password')     
        if username == user['username'] and password == user['password']:
            
            session['user'] = username
            return redirect('/dashboard')

        return "<h1>Wrong username or password</h1>"    #if the username or password does not matches 

    return render_template("login.html")



if __name__ == '__main__':
    app.debug = True
    app.run(host='127.0.0.1')
