void start_coffe_machine(){
  drop_cap();
  check_machine();
  start_coffe();
}
