import {{ cookiecutter.project_name }}

{{ cookiecutter.project_name}}.main()
