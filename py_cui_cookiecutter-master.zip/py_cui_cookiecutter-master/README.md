# py_cui cookiecutter

This project is meant to simplify templating a new [`py_cui`](https://github.com/jwlodek/py_cui) based interface. To use it, first install cookiecutter:

```
pip install cookiecutter
```

and then run it using this template:

```
cookiecutter https://github.com/jwlodek/py_cui_cookiecutter
```

and fill out any prompts that are displayed, or alternatively leave them blank for a default value to be entered for you.
